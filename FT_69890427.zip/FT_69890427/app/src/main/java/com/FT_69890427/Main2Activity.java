package com.FT_69890427;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    Button btn1;
   Button btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button btnACtion1 = findViewById(R.id.btn1);

        btnACtion1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

         //       Toast.makeText(Main2Activity.this, "BTN !", Toast.LENGTH_SHORT).show();
                   Intent i1;
                i1 = new Intent(Main2Activity.this,MainActivity.class);
                startActivity(i1);
            }
        });

        Button btnACtion = findViewById(R.id.btn2);

        btnACtion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            //    Toast.makeText(Main2Activity.this, "BTN !", Toast.LENGTH_SHORT).show();

                Intent i;
                i = new Intent(Main2Activity.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}
